﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KumAndGo
{
    public partial class FillingUp : Form
    {
        public FillingUp()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            panel1.Width += 3;

            if (panel1.Width >= 599)
            {
                this.Hide();
                timer1.Stop();
                Receipt main = new Receipt();
                main.Show();
            }
        }
    }
}
