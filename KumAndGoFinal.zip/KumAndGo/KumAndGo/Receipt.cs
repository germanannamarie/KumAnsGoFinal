﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KumAndGo
{
    public partial class Receipt : Form
    {
        public Receipt()
        {
            InitializeComponent();
        }

        private void Receipt_Load(object sender, EventArgs e)
        {
            

        }

        private void siticoneButton1_Click(object sender, EventArgs e)
        {
            string box_msg = "Thankyou for purchacing at KUM & GO!";
            MessageBox.Show(box_msg, "", MessageBoxButtons.OK, MessageBoxIcon.Information);


            this.Hide();
            Inventory form = new Inventory();
            form.ShowDialog();

        }
    }
    }
