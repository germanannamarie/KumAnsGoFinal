﻿namespace KumAndGo
{
    partial class MenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuForm));
            this.siticonePictureBox1 = new Siticone.Desktop.UI.WinForms.SiticonePictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.siticonePanel3 = new Siticone.Desktop.UI.WinForms.SiticonePanel();
            this.siticonePanel2 = new Siticone.Desktop.UI.WinForms.SiticonePanel();
            this.siticonePanel1 = new Siticone.Desktop.UI.WinForms.SiticonePanel();
            this.label1 = new System.Windows.Forms.Label();
            this.siticoneHtmlLabel2 = new Siticone.Desktop.UI.WinForms.SiticoneHtmlLabel();
            this.siticonePictureBox2 = new Siticone.Desktop.UI.WinForms.SiticonePictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtLiter = new Siticone.Desktop.UI.WinForms.SiticoneTextBox();
            this.siticoneButton4 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton5 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton6 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton7 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton8 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton9 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton11 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton12 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton13 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton14 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton16 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton17 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.label5 = new System.Windows.Forms.Label();
            this.txtAmount = new Siticone.Desktop.UI.WinForms.SiticoneTextBox();
            this.siticoneButton10 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.txtInputLiter = new Siticone.Desktop.UI.WinForms.SiticoneTextBox();
            this.siticoneButton15 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.siticonePictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.siticonePictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // siticonePictureBox1
            // 
            this.siticonePictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.siticonePictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("siticonePictureBox1.Image")));
            this.siticonePictureBox1.ImageRotate = 0F;
            this.siticonePictureBox1.Location = new System.Drawing.Point(94, 10);
            this.siticonePictureBox1.Name = "siticonePictureBox1";
            this.siticonePictureBox1.Size = new System.Drawing.Size(86, 92);
            this.siticonePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.siticonePictureBox1.TabIndex = 28;
            this.siticonePictureBox1.TabStop = false;
            this.siticonePictureBox1.UseTransparentBackground = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(456, 350);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 25);
            this.label4.TabIndex = 24;
            this.label4.Text = "D I E S E L";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(220, 350);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(161, 25);
            this.label3.TabIndex = 23;
            this.label3.Text = "U N L E A D E D";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(20, 350);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(141, 25);
            this.label2.TabIndex = 22;
            this.label2.Text = "P R E M I U M";
            // 
            // siticonePanel3
            // 
            this.siticonePanel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("siticonePanel3.BackgroundImage")));
            this.siticonePanel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.siticonePanel3.Location = new System.Drawing.Point(429, 109);
            this.siticonePanel3.Name = "siticonePanel3";
            this.siticonePanel3.Size = new System.Drawing.Size(158, 238);
            this.siticonePanel3.TabIndex = 20;
            // 
            // siticonePanel2
            // 
            this.siticonePanel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("siticonePanel2.BackgroundImage")));
            this.siticonePanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.siticonePanel2.Location = new System.Drawing.Point(222, 109);
            this.siticonePanel2.Name = "siticonePanel2";
            this.siticonePanel2.Size = new System.Drawing.Size(158, 238);
            this.siticonePanel2.TabIndex = 21;
            // 
            // siticonePanel1
            // 
            this.siticonePanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("siticonePanel1.BackgroundImage")));
            this.siticonePanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.siticonePanel1.Location = new System.Drawing.Point(12, 109);
            this.siticonePanel1.Name = "siticonePanel1";
            this.siticonePanel1.Size = new System.Drawing.Size(158, 238);
            this.siticonePanel1.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(251, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 28);
            this.label1.TabIndex = 17;
            this.label1.Text = "K U M & G O ";
            this.label1.UseMnemonic = false;
            // 
            // siticoneHtmlLabel2
            // 
            this.siticoneHtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.siticoneHtmlLabel2.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneHtmlLabel2.ForeColor = System.Drawing.Color.White;
            this.siticoneHtmlLabel2.Location = new System.Drawing.Point(186, 51);
            this.siticoneHtmlLabel2.Name = "siticoneHtmlLabel2";
            this.siticoneHtmlLabel2.Size = new System.Drawing.Size(314, 30);
            this.siticoneHtmlLabel2.TabIndex = 18;
            this.siticoneHtmlLabel2.Text = "G A S O L I N E S T A T I O N";
            // 
            // siticonePictureBox2
            // 
            this.siticonePictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.siticonePictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("siticonePictureBox2.Image")));
            this.siticonePictureBox2.ImageRotate = 0F;
            this.siticonePictureBox2.Location = new System.Drawing.Point(572, 1);
            this.siticonePictureBox2.Name = "siticonePictureBox2";
            this.siticonePictureBox2.Size = new System.Drawing.Size(22, 28);
            this.siticonePictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.siticonePictureBox2.TabIndex = 149;
            this.siticonePictureBox2.TabStop = false;
            this.siticonePictureBox2.UseTransparentBackground = true;
            this.siticonePictureBox2.Click += new System.EventHandler(this.siticonePictureBox2_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(312, 437);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 25);
            this.label6.TabIndex = 150;
            this.label6.Text = "LITER:";
            // 
            // txtLiter
            // 
            this.txtLiter.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLiter.DefaultText = "";
            this.txtLiter.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtLiter.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtLiter.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtLiter.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtLiter.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtLiter.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtLiter.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtLiter.Location = new System.Drawing.Point(448, 437);
            this.txtLiter.Name = "txtLiter";
            this.txtLiter.PasswordChar = '\0';
            this.txtLiter.PlaceholderText = "";
            this.txtLiter.SelectedText = "";
            this.txtLiter.Size = new System.Drawing.Size(88, 25);
            this.txtLiter.TabIndex = 151;
            // 
            // siticoneButton4
            // 
            this.siticoneButton4.BorderRadius = 15;
            this.siticoneButton4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton4.FillColor = System.Drawing.Color.SeaGreen;
            this.siticoneButton4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton4.ForeColor = System.Drawing.Color.White;
            this.siticoneButton4.Location = new System.Drawing.Point(200, 614);
            this.siticoneButton4.Name = "siticoneButton4";
            this.siticoneButton4.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton4.TabIndex = 165;
            this.siticoneButton4.Text = "ENTER";
            this.siticoneButton4.Click += new System.EventHandler(this.siticoneButton4_Click);
            // 
            // siticoneButton5
            // 
            this.siticoneButton5.BorderRadius = 15;
            this.siticoneButton5.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton5.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton5.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton5.FillColor = System.Drawing.Color.Goldenrod;
            this.siticoneButton5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton5.ForeColor = System.Drawing.Color.White;
            this.siticoneButton5.Location = new System.Drawing.Point(18, 614);
            this.siticoneButton5.Name = "siticoneButton5";
            this.siticoneButton5.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton5.TabIndex = 164;
            this.siticoneButton5.Text = "CLEAR";
            this.siticoneButton5.Click += new System.EventHandler(this.siticoneButton5_Click);
            // 
            // siticoneButton6
            // 
            this.siticoneButton6.BorderRadius = 15;
            this.siticoneButton6.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton6.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton6.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton6.FillColor = System.Drawing.Color.SteelBlue;
            this.siticoneButton6.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton6.ForeColor = System.Drawing.Color.White;
            this.siticoneButton6.Location = new System.Drawing.Point(109, 614);
            this.siticoneButton6.Name = "siticoneButton6";
            this.siticoneButton6.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton6.TabIndex = 163;
            this.siticoneButton6.Text = "0";
            this.siticoneButton6.Click += new System.EventHandler(this.siticoneButton6_Click);
            // 
            // siticoneButton7
            // 
            this.siticoneButton7.BorderRadius = 15;
            this.siticoneButton7.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton7.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton7.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton7.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton7.FillColor = System.Drawing.Color.SteelBlue;
            this.siticoneButton7.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton7.ForeColor = System.Drawing.Color.White;
            this.siticoneButton7.Location = new System.Drawing.Point(200, 572);
            this.siticoneButton7.Name = "siticoneButton7";
            this.siticoneButton7.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton7.TabIndex = 162;
            this.siticoneButton7.Text = "9";
            this.siticoneButton7.Click += new System.EventHandler(this.siticoneButton7_Click);
            // 
            // siticoneButton8
            // 
            this.siticoneButton8.BorderRadius = 15;
            this.siticoneButton8.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton8.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton8.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton8.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton8.FillColor = System.Drawing.Color.SteelBlue;
            this.siticoneButton8.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton8.ForeColor = System.Drawing.Color.White;
            this.siticoneButton8.Location = new System.Drawing.Point(109, 572);
            this.siticoneButton8.Name = "siticoneButton8";
            this.siticoneButton8.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton8.TabIndex = 161;
            this.siticoneButton8.Text = "8";
            this.siticoneButton8.Click += new System.EventHandler(this.siticoneButton8_Click);
            // 
            // siticoneButton9
            // 
            this.siticoneButton9.BorderRadius = 15;
            this.siticoneButton9.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton9.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton9.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton9.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton9.FillColor = System.Drawing.Color.SteelBlue;
            this.siticoneButton9.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton9.ForeColor = System.Drawing.Color.White;
            this.siticoneButton9.Location = new System.Drawing.Point(18, 572);
            this.siticoneButton9.Name = "siticoneButton9";
            this.siticoneButton9.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton9.TabIndex = 160;
            this.siticoneButton9.Text = "7";
            this.siticoneButton9.Click += new System.EventHandler(this.siticoneButton9_Click);
            // 
            // siticoneButton11
            // 
            this.siticoneButton11.BorderRadius = 15;
            this.siticoneButton11.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton11.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton11.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton11.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton11.FillColor = System.Drawing.Color.SteelBlue;
            this.siticoneButton11.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton11.ForeColor = System.Drawing.Color.White;
            this.siticoneButton11.Location = new System.Drawing.Point(200, 530);
            this.siticoneButton11.Name = "siticoneButton11";
            this.siticoneButton11.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton11.TabIndex = 159;
            this.siticoneButton11.Text = "6";
            this.siticoneButton11.Click += new System.EventHandler(this.siticoneButton11_Click);
            // 
            // siticoneButton12
            // 
            this.siticoneButton12.BorderRadius = 15;
            this.siticoneButton12.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton12.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton12.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton12.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton12.FillColor = System.Drawing.Color.SteelBlue;
            this.siticoneButton12.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton12.ForeColor = System.Drawing.Color.White;
            this.siticoneButton12.Location = new System.Drawing.Point(109, 530);
            this.siticoneButton12.Name = "siticoneButton12";
            this.siticoneButton12.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton12.TabIndex = 158;
            this.siticoneButton12.Text = "5";
            this.siticoneButton12.Click += new System.EventHandler(this.siticoneButton12_Click);
            // 
            // siticoneButton13
            // 
            this.siticoneButton13.BorderRadius = 15;
            this.siticoneButton13.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton13.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton13.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton13.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton13.FillColor = System.Drawing.Color.SteelBlue;
            this.siticoneButton13.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton13.ForeColor = System.Drawing.Color.White;
            this.siticoneButton13.Location = new System.Drawing.Point(18, 530);
            this.siticoneButton13.Name = "siticoneButton13";
            this.siticoneButton13.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton13.TabIndex = 157;
            this.siticoneButton13.Text = "4";
            this.siticoneButton13.Click += new System.EventHandler(this.siticoneButton13_Click);
            // 
            // siticoneButton14
            // 
            this.siticoneButton14.BorderRadius = 15;
            this.siticoneButton14.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton14.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton14.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton14.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton14.FillColor = System.Drawing.Color.SteelBlue;
            this.siticoneButton14.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton14.ForeColor = System.Drawing.Color.White;
            this.siticoneButton14.Location = new System.Drawing.Point(200, 488);
            this.siticoneButton14.Name = "siticoneButton14";
            this.siticoneButton14.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton14.TabIndex = 156;
            this.siticoneButton14.Text = "3";
            this.siticoneButton14.Click += new System.EventHandler(this.siticoneButton14_Click);
            // 
            // siticoneButton16
            // 
            this.siticoneButton16.BorderRadius = 15;
            this.siticoneButton16.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton16.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton16.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton16.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton16.FillColor = System.Drawing.Color.SteelBlue;
            this.siticoneButton16.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton16.ForeColor = System.Drawing.Color.White;
            this.siticoneButton16.Location = new System.Drawing.Point(109, 488);
            this.siticoneButton16.Name = "siticoneButton16";
            this.siticoneButton16.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton16.TabIndex = 155;
            this.siticoneButton16.Text = "2";
            this.siticoneButton16.Click += new System.EventHandler(this.siticoneButton16_Click);
            // 
            // siticoneButton17
            // 
            this.siticoneButton17.BorderRadius = 15;
            this.siticoneButton17.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton17.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton17.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton17.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton17.FillColor = System.Drawing.Color.SteelBlue;
            this.siticoneButton17.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton17.ForeColor = System.Drawing.Color.White;
            this.siticoneButton17.Location = new System.Drawing.Point(18, 488);
            this.siticoneButton17.Name = "siticoneButton17";
            this.siticoneButton17.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton17.TabIndex = 154;
            this.siticoneButton17.Text = "1";
            this.siticoneButton17.Click += new System.EventHandler(this.siticoneButton17_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(312, 468);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 25);
            this.label5.TabIndex = 166;
            this.label5.Text = "AMOUNT:";
            // 
            // txtAmount
            // 
            this.txtAmount.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtAmount.DefaultText = "";
            this.txtAmount.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtAmount.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtAmount.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtAmount.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtAmount.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtAmount.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtAmount.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtAmount.Location = new System.Drawing.Point(448, 468);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.PasswordChar = '\0';
            this.txtAmount.PlaceholderText = "";
            this.txtAmount.SelectedText = "";
            this.txtAmount.Size = new System.Drawing.Size(88, 25);
            this.txtAmount.TabIndex = 167;
            // 
            // siticoneButton10
            // 
            this.siticoneButton10.BorderRadius = 15;
            this.siticoneButton10.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton10.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton10.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton10.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.siticoneButton10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton10.ForeColor = System.Drawing.Color.White;
            this.siticoneButton10.Location = new System.Drawing.Point(391, 516);
            this.siticoneButton10.Name = "siticoneButton10";
            this.siticoneButton10.Size = new System.Drawing.Size(109, 36);
            this.siticoneButton10.TabIndex = 168;
            this.siticoneButton10.Text = "PROCESS";
            this.siticoneButton10.Click += new System.EventHandler(this.siticoneButton10_Click_1);
            // 
            // txtInputLiter
            // 
            this.txtInputLiter.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtInputLiter.DefaultText = "";
            this.txtInputLiter.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtInputLiter.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtInputLiter.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtInputLiter.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtInputLiter.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtInputLiter.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtInputLiter.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtInputLiter.Location = new System.Drawing.Point(72, 437);
            this.txtInputLiter.Name = "txtInputLiter";
            this.txtInputLiter.PasswordChar = '\0';
            this.txtInputLiter.PlaceholderText = "";
            this.txtInputLiter.SelectedText = "";
            this.txtInputLiter.Size = new System.Drawing.Size(181, 35);
            this.txtInputLiter.TabIndex = 169;
            // 
            // siticoneButton15
            // 
            this.siticoneButton15.BorderRadius = 15;
            this.siticoneButton15.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton15.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton15.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton15.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton15.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.siticoneButton15.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton15.ForeColor = System.Drawing.Color.White;
            this.siticoneButton15.Location = new System.Drawing.Point(391, 558);
            this.siticoneButton15.Name = "siticoneButton15";
            this.siticoneButton15.Size = new System.Drawing.Size(109, 36);
            this.siticoneButton15.TabIndex = 170;
            this.siticoneButton15.Text = "BACK";
            this.siticoneButton15.Click += new System.EventHandler(this.siticoneButton15_Click_1);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(10, 355);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(14, 13);
            this.radioButton1.TabIndex = 171;
            this.radioButton1.TabStop = true;
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(209, 355);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(14, 13);
            this.radioButton2.TabIndex = 172;
            this.radioButton2.TabStop = true;
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(444, 355);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(14, 13);
            this.radioButton3.TabIndex = 173;
            this.radioButton3.TabStop = true;
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // MenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.ClientSize = new System.Drawing.Size(598, 705);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.siticoneButton15);
            this.Controls.Add(this.txtInputLiter);
            this.Controls.Add(this.siticoneButton10);
            this.Controls.Add(this.txtAmount);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.siticoneButton4);
            this.Controls.Add(this.siticoneButton5);
            this.Controls.Add(this.siticoneButton6);
            this.Controls.Add(this.siticoneButton7);
            this.Controls.Add(this.siticoneButton8);
            this.Controls.Add(this.siticoneButton9);
            this.Controls.Add(this.siticoneButton11);
            this.Controls.Add(this.siticoneButton12);
            this.Controls.Add(this.siticoneButton13);
            this.Controls.Add(this.siticoneButton14);
            this.Controls.Add(this.siticoneButton16);
            this.Controls.Add(this.siticoneButton17);
            this.Controls.Add(this.txtLiter);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.siticonePictureBox2);
            this.Controls.Add(this.siticonePictureBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.siticonePanel3);
            this.Controls.Add(this.siticonePanel2);
            this.Controls.Add(this.siticonePanel1);
            this.Controls.Add(this.siticoneHtmlLabel2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MenuForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MenuForm";
            ((System.ComponentModel.ISupportInitialize)(this.siticonePictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.siticonePictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Siticone.Desktop.UI.WinForms.SiticonePictureBox siticonePictureBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private Siticone.Desktop.UI.WinForms.SiticonePanel siticonePanel3;
        private Siticone.Desktop.UI.WinForms.SiticonePanel siticonePanel2;
        private Siticone.Desktop.UI.WinForms.SiticonePanel siticonePanel1;
        private System.Windows.Forms.Label label1;
        private Siticone.Desktop.UI.WinForms.SiticoneHtmlLabel siticoneHtmlLabel2;
        private Siticone.Desktop.UI.WinForms.SiticonePictureBox siticonePictureBox2;
        private System.Windows.Forms.Label label6;
        private Siticone.Desktop.UI.WinForms.SiticoneTextBox txtLiter;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton4;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton5;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton6;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton7;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton8;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton9;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton11;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton12;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton13;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton14;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton16;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton17;
        private System.Windows.Forms.Label label5;
        private Siticone.Desktop.UI.WinForms.SiticoneTextBox txtAmount;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton10;
        private Siticone.Desktop.UI.WinForms.SiticoneTextBox txtInputLiter;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton15;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
    }
}