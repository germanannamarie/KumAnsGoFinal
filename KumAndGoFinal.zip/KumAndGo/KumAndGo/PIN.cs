﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace KumAndGo
{
    public partial class PIN : Form
    {
        double number;
        public PIN()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void siticoneButton1_Click(object sender, EventArgs e)
        {
            string pin = "2023";

            if (PinNum.Text == pin)
            {
                string box_msg = "LOG-IN SUCCESSFULLY!";
                MessageBox.Show(box_msg, "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                this.Hide();
                AccountDetails f3 = new AccountDetails();
                f3.ShowDialog();
            }
            else
            {
                string box_msg = "INVALID PIN!";
                MessageBox.Show(box_msg, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PIN_Load(object sender, EventArgs e)
        {

        }

        private void siticoneButton5_Click(object sender, EventArgs e)
        {
            number = 5;
            PinNum.Text += number;
        }

        private void siticoneButton8_Click(object sender, EventArgs e)
        {
            number = 8;
            PinNum.Text += number;
        }

        private void one_Click(object sender, EventArgs e)
        {
            number = 1;
            PinNum.Text += number;
        }

        private void two_Click(object sender, EventArgs e)
        {
            number = 2;
            PinNum.Text += number;
        }

        private void three_Click(object sender, EventArgs e)
        {
            number = 3;
            PinNum.Text += number;
        }

        private void four_Click(object sender, EventArgs e)
        {
            number = 4;
            PinNum.Text += number;
        }

        private void six_Click(object sender, EventArgs e)
        {
            number = 6;
            PinNum.Text += number;
        }

        private void seven_Click(object sender, EventArgs e)
        {
            number = 7;
            PinNum.Text += number;
        }

        private void nine_Click(object sender, EventArgs e)
        {
            number = 9;
            PinNum.Text += number;
        }

        private void zero_Click(object sender, EventArgs e)
        {
            number = 0;
            PinNum.Text += number;
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            PinNum.Text = "";
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void PinNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void PinNum_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
