﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace KumAndGo
{
    public partial class MenuForm : Form
    {
        double number;

        public MenuForm()
        {
            InitializeComponent();
        }
        public static class GlobalVar
        {
            
        }

        private void siticoneButton2_Click(object sender, EventArgs e)
        {
            
        }

        private void siticoneButton1_Click(object sender, EventArgs e)
        {
           
        }

        private void siticonePictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void siticoneButton3_Click(object sender, EventArgs e)
        {
            
        }

        private void one_Click(object sender, EventArgs e)
        {
            number = 1;
            txtInputLiter.Text += number;
        }

        private void two_Click(object sender, EventArgs e)
        {
            number = 2;
            txtInputLiter.Text += number;
        }

        private void three_Click(object sender, EventArgs e)
        {
            number = 3;
            txtInputLiter.Text += number;
        }

        private void four_Click(object sender, EventArgs e)
        {
            number = 4;
            txtInputLiter.Text += number;
        }

        private void five_Click(object sender, EventArgs e)
        {
            number = 5;
            txtInputLiter.Text += number;
        }

        private void six_Click(object sender, EventArgs e)
        {
            number = 6;
            txtInputLiter.Text += number;
        }

        private void seven_Click(object sender, EventArgs e)
        {
            number = 7;
            txtInputLiter.Text += number;
        }

        private void eight_Click(object sender, EventArgs e)
        {
            number = 8;
            txtInputLiter.Text += number;
        }

        private void nine_Click(object sender, EventArgs e)
        {
            number = 0;
            txtLiter.Text += number;
        }

        private void siticoneButton10_Click(object sender, EventArgs e)
        {
            number = 0;
            txtInputLiter.Text += number;
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            txtInputLiter.Text = "";
        }

        private void siticoneButton15_Click(object sender, EventArgs e)
        {
            
        }

        private void AmountText_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void AmountText_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8 && ch != 46);
            {
                e.Handled = true;
            }
        }

        private void siticoneButton17_Click(object sender, EventArgs e)
        {
            number = 1;
            txtInputLiter.Text += number;
        }

        private void siticoneButton16_Click(object sender, EventArgs e)
        {
            number = 2;
            txtInputLiter.Text += number;
        }

        private void siticoneButton14_Click(object sender, EventArgs e)
        {
            number = 3;
            txtInputLiter.Text += number;
        }

        private void siticoneButton13_Click(object sender, EventArgs e)
        {
            number = 4;
            txtInputLiter.Text += number;
        }

        private void siticoneButton12_Click(object sender, EventArgs e)
        {
            number = 5;
            txtInputLiter.Text += number;
        }

        private void siticoneButton11_Click(object sender, EventArgs e)
        {
            number = 6;
            txtInputLiter.Text += number;
        }

        private void siticoneButton9_Click(object sender, EventArgs e)
        {
            number = 7;
            txtInputLiter.Text += number;
        }

        private void siticoneButton8_Click(object sender, EventArgs e)
        {
            number = 8;
            txtInputLiter.Text += number;
        }

        private void siticoneButton7_Click(object sender, EventArgs e)
        {
            number = 9;
            txtInputLiter.Text += number;
        }

        private void siticoneButton6_Click(object sender, EventArgs e)
        {
            number = 0;
            txtInputLiter.Text += number;
        }

        private void siticoneButton5_Click(object sender, EventArgs e)
        {
            txtLiter.Text = "";
            txtAmount.Text = "";
            txtInputLiter.Text = "";
        }

        private void siticoneButton10_Click_1(object sender, EventArgs e)
        {
            double Amount;
            Amount = Convert.ToDouble(txtAmount.Text);

            if (Amount <= 5000)
            {
                PIN frm = new PIN();
                this.Hide();
                frm.ShowDialog();

            }
            else
            {
                MessageBox.Show("Insufficient Balance!");

            }
        }

        private void siticoneButton4_Click(object sender, EventArgs e)
        {
            double Liter;
            double Amount;

            if (radioButton1.Checked)
            {
                txtLiter.Text = txtInputLiter.Text.ToString();
                Liter = Convert.ToDouble(txtInputLiter.Text);
                Amount = Liter * 62;
                txtAmount.Text = Amount.ToString();
            }
            else if (radioButton2.Checked)
            {
                txtLiter.Text = txtInputLiter.Text.ToString();
                Liter = Convert.ToDouble(txtInputLiter.Text);
                Amount = Liter * 50;
                txtAmount.Text = Amount.ToString();
            }
            else if (radioButton3.Checked)
            {
                txtLiter.Text = txtInputLiter.Text.ToString();
                Liter = Convert.ToDouble(txtInputLiter.Text);
                Amount = Liter * 59;
                txtAmount.Text = Amount.ToString();
            }
        }

        private void siticoneButton15_Click_1(object sender, EventArgs e)
        {
            AccountDetails crd = new AccountDetails();
            this.Hide();
            crd.ShowDialog();
        }
    }
    }
