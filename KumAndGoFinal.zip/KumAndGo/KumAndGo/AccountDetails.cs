﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace KumAndGo
{
    public partial class AccountDetails : Form
    {
        public AccountDetails()
        {
            InitializeComponent();
        }

        private void AccountDetails_Load(object sender, EventArgs e)
        {
            
        }

        private void siticoneButton15_Click(object sender, EventArgs e)
        {
            
        }

        private void cash_Click(object sender, EventArgs e)
        {

        }

        private void siticoneTextBox1_TextChanged(object sender, EventArgs e)
        {
           
           
        }

        private void siticoneTextBox2_TextChanged(object sender, EventArgs e)
        {
            
            
            
        }

        private void siticoneTextBox3_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void siticoneButton10_Click(object sender, EventArgs e)
        {
            this.Hide();
            FillingUp main = new FillingUp();
            main.Show();
        }

        private void siticoneButton15_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            PIN main = new PIN();
            main.Show();
        }

        private void siticoneButton1_Click(object sender, EventArgs e)
        {
            txtName.Text = "ROEMA T. PALAD";
            txtNum.Text = "0168-7359-4620-1403";
            txtBal.Text = "Php 3,000";
        }
    }
}
